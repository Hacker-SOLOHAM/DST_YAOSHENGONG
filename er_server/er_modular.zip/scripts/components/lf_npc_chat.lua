--ByLaolu 行为判定组件类
--置空,挂接机制使用.
local Lf_npc_chat = Class(function(self, inst)
    self.inst = inst
end)
return Lf_npc_chat